package com.example.eventtracker;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddEvent extends AppCompatActivity {
    EditText EventName, DateTime, EventDesc;
    Button insert, update, delete, view;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EventName = findViewById(R.id.name);
        DateTime = findViewById(R.id.dateTime);
        EventDesc = findViewById(R.id.eventDesc);
        insert = findViewById(R.id.btnInsert);
        update = findViewById(R.id.btnUpdate);
        delete = findViewById(R.id.btnDelete);
        view = findViewById(R.id.btnView);
        DB = new DBHelper(this);

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameTXT = EventName.getText().toString();
                String dateTXT = DateTime.getText().toString();
                String descTXT = EventDesc.getText().toString();

                Boolean checkinsertdata = DB.insertEventData(nameTXT, dateTXT, descTXT);
                if(checkinsertdata==true)
                    Toast.makeText(AddEvent.this, "New Entry Inserted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(AddEvent.this, "New Entry Not Inserted", Toast.LENGTH_SHORT).show();
            }        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameTXT = EventName.getText().toString();
                String dateTXT = DateTime.getText().toString();
                String descTXT = EventDesc.getText().toString();

                Boolean checkupdatedata = DB.updateEventData(nameTXT, dateTXT, descTXT);
                if(checkupdatedata==true)
                    Toast.makeText(AddEvent.this, "Entry Updated", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(AddEvent.this, "New Entry Not Updated", Toast.LENGTH_SHORT).show();
            }        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameTXT = EventName.getText().toString();
                Boolean checkudeletedata = DB.deleteData(nameTXT);
                if(checkudeletedata==true)
                    Toast.makeText(AddEvent.this, "Entry Deleted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(AddEvent.this, "Entry Not Deleted", Toast.LENGTH_SHORT).show();
            }        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = DB.getdata();
                if(res.getCount()==0){
                    Toast.makeText(AddEvent.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while(res.moveToNext()){
                    buffer.append("Name :"+res.getString(0)+"\n");
                    buffer.append("Event Date :"+res.getString(1)+"\n");
                    buffer.append("Event Description :"+res.getString(2)+"\n\n");
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(AddEvent.this);
                builder.setCancelable(true);
                builder.setTitle("Event Entries");
                builder.setMessage(buffer.toString());
                builder.show();
            }        });
    }}