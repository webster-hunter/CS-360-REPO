package com.example.eventtracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHandler extends SQLiteOpenHelper {

    // creating a constant variables for our database.
    // below variable is for our database name.
    private static final String DB_NAME = "coursedb";

    // below int is our database version
    private static final int DB_VERSION = 1;

    // below variable is for our table name.
    private static final String TABLE_NAME = "events";

    // below variable is for our id column.
    private static final String ID_COL = "id";

    // below variable is for our event name column
    private static final String NAME_COL = "name";

    // below variable id for our date column.
    private static final String DATE_COL = "date";

    // below variable for our course description column.
    private static final String DESCRIPTION_COL = "description";

    // creating a constructor for our database handler.
    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // create database
    @Override
    public void onCreate(SQLiteDatabase db) {
        // setting our column names
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NAME_COL + " TEXT,"
                + DATE_COL + " TEXT,"
                + DESCRIPTION_COL + " TEXT)";

        // execute sql query
        db.execSQL(query);
    }

    // add new event
    public void addNewEvent(String eventName, String eventDate, String eventDesc) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(NAME_COL, eventName);
        values.put(DATE_COL, eventDate);
        values.put(DESCRIPTION_COL, eventDesc);

        // pass contents to table
        db.insert(TABLE_NAME, null, values);

        // close db
        db.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // this method is called to check if the table exists already.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}