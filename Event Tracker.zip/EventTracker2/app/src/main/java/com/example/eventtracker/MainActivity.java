package com.example.eventtracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText Username;
    private EditText Password;
    private Button Login;
    private Button ForgotPwd;
    private Button Register;
    private TextView badLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Username = (EditText)findViewById(R.id.etlemail);
        Password = (EditText)findViewById(R.id.etlpwd);
        Login = (Button)findViewById(R.id.btnlogin);
        ForgotPwd = (Button)findViewById(R.id.btnforgotpwd);
        Register = (Button)findViewById(R.id.btnregister);
        badLogin = (TextView)findViewById(R.id.loginFail);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validate(Username.getText().toString(), Password.getText().toString());
            }
        });
    }

    private void validate(String username, String pwd) {
        if((username == "test") && (pwd == "test")) {
            Intent intent = new Intent(MainActivity.this,Activity2.class);
            startActivity(intent);
        }
        else {
            loginFail();
        }
    }

    private void loginFail() {
        badLogin.setText("Invalid Username/Password");
    }
}